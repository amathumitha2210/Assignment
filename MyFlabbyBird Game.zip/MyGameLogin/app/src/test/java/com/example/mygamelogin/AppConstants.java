package com.example.mygamelogin;

public class AppConstants {
}
