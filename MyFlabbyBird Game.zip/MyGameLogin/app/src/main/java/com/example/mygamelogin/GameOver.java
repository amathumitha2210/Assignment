package com.example.mygamelogin;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class GameOver extends AppCompatActivity {
    Button button;

    TextView tvScore, tvPersonalScore;
    @Override
    protected void onCreate (@Nullable Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.game_over);
        int score = getIntent().getExtras().getInt("score");
        SharedPreferences pref = getSharedPreferences("MyPref",0);
        int scoreSP = pref.getInt("scoreSP",0);
        SharedPreferences.Editor editor = pref.edit();
        if(score > scoreSP){
            scoreSP = score;
            editor.putInt("scoreSP",scoreSP);
            editor.commit();

        }
        tvScore = findViewById(R.id.tvScore);
        tvPersonalScore = findViewById(R.id.tvPersonalScore);
        tvScore.setText(""+score);
        tvPersonalScore.setText(""+scoreSP);
        button = findViewById(R.id.button);


        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotLink ("https://marcconrad.com/uob/smile/index.php");
            }
        });


    }
    private void gotLink(String s){
        Uri uri = Uri.parse(s);
        startActivity(new Intent(Intent.ACTION_VIEW,uri));
    }


    public void exit (View view){
        finish();
    }
}
